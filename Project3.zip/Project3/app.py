from flask import Flask, render_template, request, redirect, url_for
from flask_pymongo import PyMongo
from flask_wtf import FlaskForm
from wtforms import StringField, DecimalField, SelectField, DateField, SubmitField
from wtforms.validators import DataRequired
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = "include_a_strong_secret_key"
app.config["MONGO_URI"] = "add_your_connection_string_from_mongodb_cloud"
mongo = PyMongo(app)


class ExpensesForm(FlaskForm):
    description = StringField('Description', validators=[DataRequired()])
    category = SelectField('Category', choices=[('groceries', 'Groceries'), ('restaurants', 'Restaurants'),
                                                ('transportation', 'Transportation'), ('utilities', 'Utilities'),
                                                ('clothing', 'Clothing'), ('healthcare', 'Healthcare'),
                                                ('entertainment', 'Entertainment')])
    cost = DecimalField('Cost', validators=[DataRequired()])
    date = DateField('Date', format='%Y-%m-%d', validators=[DataRequired()])
    submit = SubmitField('Submit')


@app.route('/')
def index():
    total_expenses = mongo.db.expenses.aggregate([
        {"$group": {"_id": None, "total": {"$sum": "$cost"}}}
    ])
    total = next(total_expenses)["total"]

    expenses_by_category = {}
    for category in ['groceries', 'restaurants', 'transportation', 'utilities', 'clothing', 'healthcare',
                     'entertainment']:
        total_category = mongo.db.expenses.aggregate([
            {"$match": {"category": category}},
            {"$group": {"_id": None, "total": {"$sum": "$cost"}}}
        ])
        expenses_by_category[category.capitalize()] = next(total_category)["total"] if total_category.alive else 0

    return render_template("index.html", total=total, expenses_by_category=expenses_by_category)


@app.route('/add_expense', methods=["GET", "POST"])
def add_expense():
    form = ExpensesForm()
    if form.validate_on_submit():
        expense_data = {
            "description": form.description.data,
            "category": form.category.data,
            "cost": float(form.cost.data),
            "date": form.date.data.strftime("%Y-%m-%d")
        }
        mongo.db.expenses.insert_one(expense_data)
        return redirect(url_for('expense_added'))
    return render_template("add_expense.html", form=form)


@app.route('/expense_added')
def expense_added():
    return render_template("expense_added.html")


if __name__ == "__main__":
    app.run(debug=True)
