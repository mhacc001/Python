import requests
import streamlit as st
import pandas as pd
from nltk import word_tokenize
from nltk.probability import FreqDist
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import main_functions
import plotly.express as px

st.set_page_config(
        page_title="Project 1",
        page_icon="📰",
        layout="centered",
        initial_sidebar_state="expanded",
        menu_items={
            'Get Help': 'https://docs.streamlit.io/library/api-reference',
            'Report a bug': "https://docs.streamlit.io/library/api-reference",
            'About': "# This is Project 1 for COP 4813 - Prof. Gregory Reis"
        })

stop_words = set(stopwords.words("english"))

st.title("Project 1 - News App")


# Create sidebar
st.sidebar.title('News App Options')

# Add selectbox for API selection
api_selection = st.sidebar.selectbox(
    'Choose API:',
    ('Top Stories', 'Most Popular Articles')
)

# Depending on the selection, show additional options
if api_selection == 'Top Stories':
    # Add selectbox for selecting topic
    topic_selection = st.sidebar.selectbox(
        'Select Topic:',
        ["arts", "automobiles", "books", "business", "fashion", "food", "health", "home", "insider", "magazine",
         "movies", "nyregion", "opinion", "politics", "realestate", "science", "sports", "sundayreview",
         "technology", "theater", "t-magazine", "travel", "upshot", "us", "world"]
    )

    # Add slider for maximum number of words in wordcloud
    max_words = st.sidebar.slider('Maximum Words in Wordcloud:', 1, 200, 50)

    # Add color picker for wordcloud colors
    wordcloud_color = st.sidebar.color_picker('Wordcloud Color:', '#000000')

    # Add color picker for background color of wordcloud
    wordcloud_bg_color = st.sidebar.color_picker('Wordcloud Background Color:', '#FFFFFF')

    # Add checkbox for frequency distribution plot
    show_freq_dist = st.sidebar.checkbox('Show Frequency Distribution Plot')
    if show_freq_dist:
        # Add slider for number of words to display in frequency distribution plot
        num_words_freq_dist = st.sidebar.slider('Number of Words in Frequency Distribution:', 1, 20, 10)

if api_selection == 'Most Popular Articles':
    # Add selectbox for selecting article set
    article_set_selection = st.sidebar.selectbox(
        'Select Article Set:',
        ('Shared', 'Emailed', 'Viewed')
    )

    # Add selectbox for selecting time period
    time_period_selection = st.sidebar.selectbox(
        'Select Time Period:',
        ('1 day', '7 days', '30 days')
    )

# Main Page Content
st.title('News App')

if api_selection == 'Top Stories':
    st.write(f"Displaying top stories on '{topic_selection}'")
    st.write(f"Wordcloud Settings: Max Words - {max_words}, Color - {wordcloud_color}, Background Color - {wordcloud_bg_color}")
    if show_freq_dist:
        st.write(f"Frequency Distribution Plot: Number of Words - {num_words_freq_dist}")

elif api_selection == 'Most Popular Articles':
    st.write(f"Displaying most popular articles from '{article_set_selection}' in the last '{time_period_selection}'")
